# v0.7.0 Release Candidate

SMF → Glass WG → Bare Silicon → Mode Converter → Passive Packaging → Manufacturing의 6개 개발 Chapter로 기본 경험을 재구성했습니다. 기존 Mission 01–10, Free Practice, Interface Builder와 v0.6 Assembly Challenge는 Optional Engineering Lab에 보존합니다.

새 기능: 정규화된 회전 Elliptical/Complex Gaussian Overlap, Lens q/Ray/Coordinate 통합, 교육용 Converter Reference, 동일 Cohort의 Passive 설계 비교, 실제 Component 설치, Frozen Project와 제조 연결, 명확한 완료 CTA, Auto Resume와 Paste-first Backup/Restore, 설계 재전달 Archive.

기준선: main v0.5 `80fe758`; 개발 기준 v0.6 `2d52ce7`, 아직 열린 PR #6. 이 PR을 main에 바로 비교하면 v0.6 변경도 포함됩니다. 순서대로 검토하거나 #6 병합 후 rebase할 수 있으며 병합은 사용자 승인 후만 수행합니다.

핵심 모델 범위: Gaussian Reduced-order 교육 모델. Converter Output Field/Loss, Normal Error, Cost/Time는 명시적 가정입니다. 검증된 PDK/실측 Factory Yield를 주장하지 않습니다. 산업용 특정 제품 재현은 후속 범위입니다.

`optical-packaging-master-v0.7.html`은 외부 Asset/Font/CDN/API가 없는 Single HTML입니다. Preview는 1–4 Chapter의 단계별 구현 시점 체크포인트이며 저장 없는 모드입니다. Release ZIP은 실행본, Modular Source, 문서, 자동 QA 결과, 실제 스크린샷을 포함합니다. 기존 Release Artifact는 변경하지 않습니다.

QA 결과와 실행/미실행 엔진은 TEST_SUMMARY.md와 JSON Evidence를 참조하세요. Human Learning/Enjoyment 연구는 수행하지 않았습니다. Release Candidate이며 아직 main에 병합하지 않습니다.
